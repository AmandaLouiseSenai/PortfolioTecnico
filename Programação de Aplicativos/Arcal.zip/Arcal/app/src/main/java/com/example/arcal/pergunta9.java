package com.example.arcal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

public class pergunta9 extends AppCompatActivity {
    Button button8;
    static int caua;
    RadioButton a, b, c, d, e;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta9);
        getSupportActionBar().hide();
        button8 = findViewById(R.id.button8);
        a = findViewById(R.id.radioa9);
        b = findViewById(R.id.radiob9);
        c = findViewById(R.id.radioc9);
        d = findViewById(R.id.radiod9);
        e = findViewById(R.id.radioe9);
    }

    public void z(View v) {
        if (a.isChecked()) {
            caua += 5;
        } else if (b.isChecked()) {
            caua += 10;


        } else if (c.isChecked()) {
            caua += 15;

        } else if (d.isChecked()) {
            caua += 20;

        } else if (e.isChecked()) {
            caua += 25;


        } else {

            Toast.makeText(this, "Selecione pelo menos uma opção", Toast.LENGTH_SHORT).show();
        }
        Intent i = new Intent(this, pergunta10.class);
        pergunta10.caua = caua;

        startActivity(i);

    }
}
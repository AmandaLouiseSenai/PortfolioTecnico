package com.example.arcal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class PERGUNTAcc extends AppCompatActivity {
    Button button22;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perguntacc);
        getSupportActionBar().hide();
        button22 = findViewById(R.id.button22);

    }

    public void ii(View v) {
        Intent i = new Intent(this, r5a.class);
        startActivity(i);
    }
}
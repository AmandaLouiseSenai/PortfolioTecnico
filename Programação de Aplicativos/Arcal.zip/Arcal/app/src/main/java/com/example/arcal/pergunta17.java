package com.example.arcal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

public class pergunta17 extends AppCompatActivity {
    static int caua;
    RadioButton a, b, c, d, e;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta17);
        getSupportActionBar().hide();
        a = findViewById(R.id.radioa17);
        b = findViewById(R.id.radiob17);
        c = findViewById(R.id.radioc17);
        d = findViewById(R.id.radiod17);
        e = findViewById(R.id.radioe17);
    }
    public void ja(View v) {
        if (a.isChecked()) {
            caua += 5;
        } else if (b.isChecked()) {
            caua += 10;


        } else if (c.isChecked()) {
            caua += 15;

        } else if (d.isChecked()) {
            caua += 20;

        } else if (e.isChecked()) {
            caua += 25;


        } else {

            Toast.makeText(this, "Selecione pelo menos uma opção", Toast.LENGTH_LONG).show();
        }


        exibeResultado();

    }
    public void exibeResultado(){
                if (caua >= 80 && caua >= 159) {
                    Intent i = new Intent(this, perguntaa.class);
                    startActivity(i);
                }

                else if (caua >= 160 && caua <= 239) {
                    Intent ir = new Intent(this, perguntac.class);
                    startActivity(ir);
                }

                else if (caua >= 240 && caua <= 319) {
                    Intent ic = new Intent(this, perguntab.class);
                    startActivity(ic);
                }

                else if (caua >= 320 && caua > 400) {
                    Intent ib = new Intent(this, PERGUNTAcc.class);
                    startActivity(ib);
                }


    }
    public void exibecaua(View c){
        Toast.makeText(this,"Caua esta armazenando: "+caua, Toast.LENGTH_SHORT).show();

    }
}

package com.example.arcal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

public class pergunta7 extends AppCompatActivity {
    Button button6;
    static int caua;
    RadioButton a, b, c, d, e;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta7);
        getSupportActionBar().hide();
        button6 = findViewById(R.id.button6);
        a = findViewById(R.id.radioa7);
        b = findViewById(R.id.radiob7);
        c = findViewById(R.id.radioc7);
        d = findViewById(R.id.radiod7);
        e = findViewById(R.id.radioe7);

    }

    public void i(View v) {
            if (a.isChecked()) {
                caua += 5;
            } else if (b.isChecked()) {
                caua += 10;


            } else if (c.isChecked()) {
                caua += 15;

            } else if (d.isChecked()) {
                caua += 20;

            } else if (e.isChecked()) {
                caua += 25;


            } else {

                Toast.makeText(this, "Selecione pelo menos uma opção", Toast.LENGTH_SHORT).show();
            }
            Intent i = new Intent(this, pergunta8.class);
        pergunta8.caua = caua;

        startActivity(i);
        }
    }

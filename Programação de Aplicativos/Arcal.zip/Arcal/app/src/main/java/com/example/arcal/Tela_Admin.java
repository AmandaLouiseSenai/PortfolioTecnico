package com.example.arcal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class Tela_Admin extends AppCompatActivity {
    EditText login, senha, nomeuso;
    Button button16;
    static ArrayList<Usuario> list;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_admin);
        getSupportActionBar().hide();
        login = findViewById(R.id.nulogin);
        senha = findViewById(R.id.nusenha);
        nomeuso = findViewById(R.id.nomedapessoa);
        button16 = findViewById(R.id.button16);
    }

    public void cadastrar(View c) {
        try{
        String l = login.getText().toString();
        String s = senha.getText().toString();
        Usuario n = new Usuario(l, s);
        n.salvabd();
        Toast.makeText(this, "Usuario cadastrado", Toast.LENGTH_SHORT).show();
        } catch(Exception e){
            Toast.makeText(this, "Verifique os Dados", Toast.LENGTH_SHORT).show();
        }

    }

    public void aab(View v) {
        Intent i = new Intent(this, MainActivity.class);
        startActivity(i);

    }
}


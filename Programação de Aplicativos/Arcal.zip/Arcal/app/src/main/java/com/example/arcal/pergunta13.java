package com.example.arcal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

public class pergunta13 extends AppCompatActivity {
    Button button12;
    static int caua;
    RadioButton a, b, c, d, e;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta13);
        getSupportActionBar().hide();
        button12 = findViewById(R.id.button12);
        a = findViewById(R.id.radioa13);
        b = findViewById(R.id.radiob13);
        c = findViewById(R.id.radioc13);
        d = findViewById(R.id.radiod13);
        e = findViewById(R.id.radioe13);
    }
    public void n(View v) {
        if (a.isChecked()) {
            caua += 5;
        } else if (b.isChecked()) {
            caua += 10;


        } else if (c.isChecked()) {
            caua += 15;

        } else if (d.isChecked()) {
            caua += 20;

        } else if (e.isChecked()) {
            caua += 25;


        } else {

            Toast.makeText(this, "Selecione pelo menos uma opção", Toast.LENGTH_SHORT).show();
        }
        Intent i = new Intent(this, pergunta14.class);
        pergunta14.caua = caua;

        startActivity(i);
    }
}
package com.example.arcal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class perguntab extends AppCompatActivity {
    Button button21;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perguntab);
        getSupportActionBar().hide();
        button21 = findViewById(R.id.button21);
    }

    public void sg(View v) {
        Intent i = new Intent(this, r4a.class);
        startActivity(i);
    }
}
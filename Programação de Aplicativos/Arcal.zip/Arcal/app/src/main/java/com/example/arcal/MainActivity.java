package com.example.arcal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.ClosedSubscriberGroupInfo;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText campo, senha;
    TextView exibe;
    ArrayList<Usuario> usu = new ArrayList<>();
    Usuario encontrado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        campo = findViewById(R.id.login);
        exibe = findViewById(R.id.t);
        senha = findViewById(R.id.senha);
        //Usuario u = new Usuario("thomas@gmail.com", "Patrick25", 1);
//        Usuario u2 =
        //usu.add(u);
//        usu.add(u2);


    }

    public void print(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    public void clica(View c) {

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("usuarios");

        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                print("drt");
                boolean aux = false;

                String c = campo.getText().toString();
                String s = senha.getText().toString();

                for (DataSnapshot d : snapshot.getChildren()) {
                    if (d.getValue(Usuario.class).getLogin().equals(c) && d.getValue(Usuario.class).getSenha().equals(s)) {
                        print(" usuario existe ");
                        aux = true;
                        //abcd();
                        break;
                    }
                }
                if (aux == false) {
                    print(c + " não existe ");

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }


    public void mudatelaadm(View v) {
        Intent o = new Intent(this, Tela_Admin.class);
        startActivity(o);

    }

    public void abcd(View v) {
        Intent i = new Intent(this, tela1.class);
        startActivity(i);
    }



     public boolean verificaUsuario (String login, String senha){
            for (Usuario pessoa : usu) {
                if (login.equals(pessoa.login) && senha.equals(pessoa.senha)) {
                    encontrado = pessoa;

                    return true;

                }
            }
            return false;
        }


    }



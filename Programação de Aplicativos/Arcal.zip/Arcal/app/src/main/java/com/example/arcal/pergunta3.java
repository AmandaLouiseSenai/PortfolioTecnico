package com.example.arcal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

public class pergunta3 extends AppCompatActivity {
    Button button2;
    static int caua;
    RadioButton a, b , c ,d ,e;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta3);
        getSupportActionBar().hide();
        button2 = findViewById(R.id.button2);
        a =  findViewById(R.id.radioa3);
        b =  findViewById(R.id.radiob3);
        c =  findViewById(R.id.radioc3);
        d =  findViewById(R.id.radiod3);
        e =  findViewById(R.id.radioe3);
    }

    public void button2(View v) {
        if (a.isChecked()) {
            caua += 5;
        } else if (b.isChecked()) {
            caua += 10;


        } else if (c.isChecked()) {
            caua += 15;

        } else if (d.isChecked()) {
            caua += 20;

        } else if (e.isChecked()) {
            caua += 25;


        } else {

            Toast.makeText(this, "Selecione pelo menos uma opção", Toast.LENGTH_SHORT).show();
        }


        Intent i = new Intent(this, pergunta4.class);
        pergunta4.caua = caua;

        startActivity(i);
    }
}
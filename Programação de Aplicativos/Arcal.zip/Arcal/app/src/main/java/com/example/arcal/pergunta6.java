package com.example.arcal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

public class pergunta6 extends AppCompatActivity {
    Button button5;
    static int caua;
    RadioButton a, b , c ,d ,e;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pergunta6);
        getSupportActionBar().hide();
        button5 = findViewById(R.id.button5);
        a =  findViewById(R.id.radioa6);
        b =  findViewById(R.id.radiob6);
        c =  findViewById(R.id.radioc6);
        d =  findViewById(R.id.radiod6);
        e =  findViewById(R.id.radioe6);
    }
    public void o(View v) {
        if (a.isChecked()) {
            caua += 5;
        } else if (b.isChecked()) {
            caua += 10;


        } else if (c.isChecked()) {
            caua += 15;

        } else if (d.isChecked()) {
            caua += 20;

        } else if (e.isChecked()) {
            caua += 25;


        } else {

            Toast.makeText(this, "Selecione pelo menos uma opção", Toast.LENGTH_SHORT).show();
        }

        Intent i = new Intent(this, pergunta7.class);
        pergunta7.caua = caua;

        startActivity(i);
    }
}
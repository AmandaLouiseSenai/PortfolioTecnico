package com.example.thegoodme;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class TelaPerfil extends AppCompatActivity {
    static String tipovape,tiponarga,tipocigarro,tipocharuto;
    String vape,narga,cigarro,charuto;
    static int contarVape,contarNarguile,contarCigarro,contarCharuto;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_perfil);
        getSupportActionBar().hide();
        if(tipovape != ""){
            vape = "Vape";
            narga = "Narguile";
            cigarro = "Cigarro";
            charuto = "Charuto";
        }
    }
    public void clickTipos(View view){
        Toast.makeText(this, "Você fuma:\n"+vape+"\n"+narga+"\n"+cigarro+"\n"+charuto, Toast.LENGTH_LONG).show();
    }

    public void clickQuantidade(View view) {
        int resultadoSoma = contarVape + contarNarguile + contarCigarro + contarCharuto;
        String resultado = Integer.toString(resultadoSoma);
        if (resultadoSoma > 5) {
            Toast.makeText(this, "Sua quantidade de fumo por dia é: " + resultado+ "\n A QUANTIDADE DE CIGARRO QUE VOCÊ ESTÁ FUMANDO É PREOCUPANTE, PARE", Toast.LENGTH_LONG).show();
        } else{
            Toast.makeText(this, "Sua quantidade de fumo por dia é: "+resultado, Toast.LENGTH_SHORT).show();
        }
    }



}
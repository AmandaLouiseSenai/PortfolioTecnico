package com.example.thegoodme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

import java.util.ArrayList;

public class TelaTipo extends AppCompatActivity {
    RadioButton rbVp, rbng, rbch, rbcg;
    String tipoVape = "",tipoNarga = "",tipoCharuto = "",tipoCigarro = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_tipo);
        getSupportActionBar().hide();
        rbVp = findViewById(R.id.btVape);
        rbng = findViewById(R.id.btVnarga);
        rbch = findViewById(R.id.btVcharuto);
        rbcg = findViewById(R.id.btVCigarro);


    }

    public void Click(View v) {
        if (rbVp.isChecked()) {
            tipoVape = "VAPE";
        }
        if (rbng.isChecked()) {
            tipoNarga = "NARGA";

        }
        if (rbch.isChecked()) {
            tipoCharuto = "CHARUTO";

        }
        if (rbcg.isChecked()) {
            tipoCigarro = "CIGARRO";
        }
        TelaQuantidade.tipoVape = tipoVape;
        TelaQuantidade.tipoNarga = tipoNarga;
        TelaQuantidade.tipoCharuto = tipoCharuto;
        TelaQuantidade.tipoCigarro = tipoCigarro;
        TelaPerfil.tipovape = tipoVape;
        TelaPerfil.tiponarga = tipoNarga;
        TelaPerfil.tipocharuto = tipoCharuto;
        TelaPerfil.tipocigarro = tipoCigarro;
    }
        public void Proxnivel(View v){
            Intent i = new Intent(this, TelaQuantidade.class);
            startActivity(i);
        }
    }

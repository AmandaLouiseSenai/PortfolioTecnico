package com.example.geoespacial;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioButton AT, ABa, ABv, NumL, AF, V, A;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        AT = findViewById(R.id.AT);
        ABa = findViewById(R.id.ABa);
        ABv = findViewById(R.id.ABv);
        NumL = findViewById(R.id.NumL);
        AF = findViewById(R.id.AF);
        V = findViewById(R.id.V);
        A = findViewById(R.id.A);

    }



    public void click(View view) {
        Intent i = new Intent (this, Telacalculos.class);
        if (AT.isChecked()) {
            Telacalculos.formula = 1; //At = 2*Ab + NL*F
            startActivity(i);

        } else if (ABa.isChecked()){
            Telacalculos.formula = 2; // Ab = (At - NL*F)/2
            startActivity(i);
        }
        else if (ABv.isChecked()){
            Telacalculos.formula = 3; //Ab = V/H
            startActivity(i);
        }
        else if (NumL.isChecked()){
            Telacalculos.formula = 4; //NL = (At - 2*Ab)/F
            startActivity(i);
        }
        else if (AF.isChecked()){
            Telacalculos.formula = 5; //F = (At - 2*Ab)/NL
            startActivity(i);
        }
        else if (V.isChecked()){
            Telacalculos.formula = 6; //V = Ab * H
            startActivity(i);
        }
        else if (A.isChecked()){
            Telacalculos.formula = 7; //H = V/Ab
            startActivity(i);
        }
        else {
            Toast.makeText(this, "selecione uma opção", Toast.LENGTH_LONG).show();
        }
    }
}
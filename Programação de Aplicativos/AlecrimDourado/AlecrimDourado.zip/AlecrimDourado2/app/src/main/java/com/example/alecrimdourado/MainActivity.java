package com.example.alecrimdourado;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText campo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        campo = findViewById(R.id.frase);
    }
    public void clica (View v){
        String texto = campo.getText().toString();
        Toast.makeText(this,texto,Toast.LENGTH_LONG).show();

    }
}
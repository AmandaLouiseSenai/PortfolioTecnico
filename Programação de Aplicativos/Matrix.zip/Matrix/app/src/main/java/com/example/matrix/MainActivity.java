package com.example.matrix;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView mat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        mat = findViewById(R.id.matriz);
        criarmatriz();
    }
    public void criarmatriz(){
        String matriz = "Matriz\n";
        int[][] numeros = {{9,8,7},{4,5,6},{1,3,2}};
        for(int linha =0; linha < 3; linha ++){
            for(int coluna = 0; coluna <3; coluna ++){
                matriz+= numeros[linha][coluna]+"  ";
            }
            matriz += "\n";
        }
        matriz += numeros;
        mat.setText(matriz);


    }
}